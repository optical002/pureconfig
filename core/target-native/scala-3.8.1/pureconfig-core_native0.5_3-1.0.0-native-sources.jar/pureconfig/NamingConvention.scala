package pureconfig

import scala.collection.immutable.ArraySeq

trait NamingConvention {
  def toTokens(s: String): Seq[String]
  def fromTokens(l: Seq[String]): String
}

trait CapitalizedWordsNamingConvention extends NamingConvention {
  def toTokens(s: String): Seq[String] = {
    ArraySeq.unsafeWrapArray(WordBreakSplitter.splitWords(s)).map(_.toLowerCase)
  }
}

// The actual word-break splitting is delegated to `WordBreakSplitter`, defined per-platform under
// `scala-jvm/` and `scala-native/`. The JVM implementation uses a lookbehind/lookahead regex; Scala
// Native's RE2 regex engine does not support lookbehind/lookahead, so the Native variant implements
// the same word-break logic by hand. See NamingConventionPlatform.scala in those source dirs.

/** CamelCase identifiers look like `camelCase` and `useMorePureconfig`
  * @see
  *   https://en.wikipedia.org/wiki/Camel_case
  */
object CamelCase extends CapitalizedWordsNamingConvention {
  def fromTokens(l: Seq[String]): String = {
    l match {
      case Seq() => ""
      case h +: Seq() => h.toLowerCase
      case h +: t => h.toLowerCase + t.map(_.capitalize).mkString
    }
  }
}

/** PascalCase identifiers look like e.g.`PascalCase` and `UseMorePureconfig`
  * @see
  *   https://en.wikipedia.org/wiki/PascalCase
  */
object PascalCase extends CapitalizedWordsNamingConvention {
  def fromTokens(l: Seq[String]): String = l.map(_.capitalize).mkString
}

class StringDelimitedNamingConvention(d: String) extends NamingConvention {
  def toTokens(s: String): Seq[String] =
    ArraySeq.unsafeWrapArray(s.split(d)).map(_.toLowerCase)

  def fromTokens(l: Seq[String]): String =
    l.map(_.toLowerCase).mkString(d)
}

/** KebabCase identifiers look like `kebab-case` and `use-more-pureconfig`
  * @see
  *   http://wiki.c2.com/?KebabCase
  */
object KebabCase extends StringDelimitedNamingConvention("-")

/** SnakeCase identifiers look like `snake_case` and `use_more_pureconfig`
  * @see
  *   https://en.wikipedia.org/wiki/Snake_case
  */
object SnakeCase extends StringDelimitedNamingConvention("_")

/** SnakeCase identifiers look like `SCREAMING_SNAKE_CASE` and `USE_MORE_PURECONFIG`
  * @see
  *   https://en.wikipedia.org/wiki/Snake_case (and search for SCREAMING_SNAKE_CASE)
  */
object ScreamingSnakeCase extends NamingConvention {
  def toTokens(s: String): Seq[String] = SnakeCase.toTokens(s)
  def fromTokens(l: Seq[String]): String = l.map(_.toUpperCase).mkString("_")
}
